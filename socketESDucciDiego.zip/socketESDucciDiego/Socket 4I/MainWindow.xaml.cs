﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows;
using System.Windows.Threading;

namespace Socket_4I
{
    public partial class MainWindow : Window
    {
        // Socket per la comunicazione
        Socket socket = null;

        // Timer per controllare i dati ricevuti
        DispatcherTimer dTimer = null;

        // Dizionario per mappare gli indirizzi IP ai nomi degli utenti
        Dictionary<string, string> ipToName = new Dictionary<string, string>();

        public MainWindow()
        {
            InitializeComponent();

            // Inizializzazione del socket per la comunicazione
            socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

            // Impostazione dell'endpoint locale
            IPAddress local_address = IPAddress.Any; // Ascolta su tutte le interfacce di rete
            IPEndPoint local_endpoint = new IPEndPoint(local_address, 5000); // Utilizza la porta 5000
            socket.Bind(local_endpoint); // Associa il socket all'endpoint locale

            // Abilita il broadcast per il socket
            socket.EnableBroadcast = true;

            // Configurazione del timer per controllare i dati ricevuti
            dTimer = new DispatcherTimer();
            dTimer.Tick += new EventHandler(aggiornamento_dTimer);
            dTimer.Interval = new TimeSpan(0, 0, 0, 0, 250); // Ogni 250 millisecondi
            dTimer.Start();

            // Esempio di mapping IP-Nome per identificare mittenti
            ipToName["127.0.0.1"] = "Alice"; // Esempio di associazione IP a nome utente
        }

        // Metodo chiamato dal timer per controllare i dati ricevuti
        private void aggiornamento_dTimer(object sender, EventArgs e)
        {
            int nBytes = 0;

            // Verifica se ci sono dati disponibili sul socket
            if ((nBytes = socket.Available) > 0)
            {
                byte[] buffer = new byte[nBytes];
                EndPoint remoteEndPoint = new IPEndPoint(IPAddress.Any, 0); // Qualsiasi indirizzo IP e porta
                nBytes = socket.ReceiveFrom(buffer, ref remoteEndPoint); // Ricevi i dati dal socket

                // Ottieni l'indirizzo IP del mittente
                string fromIp = ((IPEndPoint)remoteEndPoint).Address.ToString();

                // Decodifica i dati ricevuti
                string messaggio = Encoding.UTF8.GetString(buffer, 0, nBytes);

                string senderName;
                // Cerca il nome del mittente nell'agenda
                if (!ipToName.TryGetValue(fromIp, out senderName))
                {
                    senderName = fromIp; // Se non trovato, usa l'indirizzo IP come nome
                }

                // Aggiungi il messaggio alla lista dei messaggi
                lstMessaggi.Items.Add($"{senderName}: {messaggio}");
            }
        }

        // Metodo chiamato quando viene premuto il pulsante "Invia"
        private void btnInvia_Click(object sender, RoutedEventArgs e)
        {
            string ipAddressString = txtTo.Text.Trim(); // Ottieni l'indirizzo IP dal campo di testo

            // Verifica se l'indirizzo IP è vuoto o è l'indirizzo di broadcast
            if (string.IsNullOrWhiteSpace(ipAddressString) || ipAddressString == "255.255.255.0")
            {
                // Invia il messaggio in broadcast
                SendBroadcastMessage();
            }
            else
            {
                // Invia il messaggio all'indirizzo IP specificato
                SendToSpecificIPAddress(ipAddressString);
            }
        }

        // Metodo per inviare un messaggio in broadcast
        private void SendBroadcastMessage()
        {
            IPAddress broadcast_address = IPAddress.Broadcast; // Ottieni l'indirizzo di broadcast
            IPEndPoint broadcast_endpoint = new IPEndPoint(broadcast_address, 6000); // Utilizza la porta 6000

            // Codifica il messaggio in UTF-8
            byte[] messaggio = Encoding.UTF8.GetBytes(txtMessaggio.Text);

            // Invia il messaggio al broadcast endpoint
            socket.SendTo(messaggio, broadcast_endpoint);
        }

        // Metodo per inviare un messaggio a un indirizzo IP specifico
        private void SendToSpecificIPAddress(string ipAddressString)
        {
            IPAddress remote_address;
            // Verifica se l'indirizzo IP specificato è valido
            if (!IPAddress.TryParse(ipAddressString, out remote_address))
            {
                MessageBox.Show("Indirizzo IP non valido.");
                return;
            }

            // Crea l'endpoint per l'indirizzo IP specificato
            IPEndPoint remote_endpoint = new IPEndPoint(remote_address, 6000); // Utilizza la porta 6000

            // Codifica il messaggio in UTF-8
            byte[] messaggio = Encoding.UTF8.GetBytes(txtMessaggio.Text);

            // Invia il messaggio all'endpoint specificato
            socket.SendTo(messaggio, remote_endpoint);
        }

    }
}
